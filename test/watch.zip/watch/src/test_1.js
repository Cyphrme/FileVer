"use strict";

import * as test2 from './test_2.js?fv=00000000';


